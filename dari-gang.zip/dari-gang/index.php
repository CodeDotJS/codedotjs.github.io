<!DOCTYPE html>
  <head>
    <title>Daari Gang - First Anniversary!</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/croppie.css" rel="stylesheet" async="async" />
    <link href="css/style.css" rel="stylesheet" async="async" />
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="js/croppie.min.js" async="async"></script>
    <script src="js/app.js" async="async"></script>
  </head>
  <body>
    <div id="wrapper">
      <div id="content">
        <h1>Dari Gang</h1>
        <p>Support Daari Gang by changing your profile picture</p>
        <div id="preview">
          <div id="crop-area">
            <img src="http://demos.subinsb.com/isl-profile-pic/image/person.png" id="profile-pic" />
          </div>
          <img src="frames/daari.png" id="fg" data-design="0" />
        </div>
        <p
          <button id="download" disabled>Download Profile Picture</button>
        </p>
        <h2>Upload</h2>
        <input type="file" name="file" onchange="onFileChange(this)">
        <?php
        require_once __DIR__ . "/footer.php";
        ?>
      </div>
    </div>
  </body>
</html>