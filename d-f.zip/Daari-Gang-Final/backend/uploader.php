<?php

if (!isset($_POST['submit'])) {
    
    require_once("uploader.html");
    exit();
    
} else {
    require_once('FacebookPicOverlay.php');
    
    $fbt = new FacebookPicOverlay();
    try {
        $image = $fbt->overlay($_FILES['picture_upload']);
    }
    catch (Exception $e) {
        print("<b>Oops!</b> " . $e->getMessage());
        print("<br /><br /><a href=\"javascript:history.go(-1)\">Please go back and try again</a>");
        exit();
    }
    
    $fbt->maintenance();
    
    require_once("success.html");
    
}

?>