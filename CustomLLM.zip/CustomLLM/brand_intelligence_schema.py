"""
Schema for Brand-Level Intelligence Data
For scraping brand websites, company information, portfolios
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, ConfigDict


class BrandIntelligenceSchema(BaseModel):
    """
    Schema for brand/company-level intelligence data
    """
    
    # === CORE IDENTIFICATION ===
    id: str = Field(..., description="Unique identifier")
    url: str = Field(..., description="Source URL")
    source: str = Field(..., description="Source (brand_website, press_release, etc.)")
    
    # === BRAND INFORMATION ===
    brand_name: str = Field(..., description="Brand name")
    company_name: Optional[str] = Field(None, description="Parent company name")
    website: Optional[str] = Field(None, description="Brand website URL")
    
    # === PORTFOLIO ===
    portfolio_brands: Optional[List[str]] = Field(None, description="Other brands in portfolio")
    key_products: Optional[List[str]] = Field(None, description="Key product lines")
    product_categories: Optional[List[str]] = Field(None, description="Product categories")
    
    # === MARKET INTELLIGENCE ===
    market_share: Optional[float] = Field(None, description="Market share percentage")
    market_rank: Optional[int] = Field(None, description="Market ranking")
    revenue: Optional[float] = Field(None, description="Revenue (if available)")
    region: Optional[str] = Field(None, description="Primary market region")
    
    # === RECENT ACTIVITIES ===
    recent_launches: Optional[List[Dict[str, Any]]] = Field(
        None, 
        description="Recent product launches with date, name, description"
    )
    pricing_strategy: Optional[str] = Field(None, description="Pricing strategy description")
    pack_strategy: Optional[str] = Field(None, description="Packaging strategy")
    
    # === POSITIONING & CLAIMS ===
    positioning: Optional[str] = Field(None, description="Brand positioning")
    marketing_claims: Optional[List[str]] = Field(None, description="Marketing claims")
    key_strengths: Optional[List[str]] = Field(None, description="Key brand strengths")
    
    # === SUSTAINABILITY ===
    sustainability_initiatives: Optional[List[str]] = Field(
        None, 
        description="Sustainability programs (Cocoa For Good, Cocoa Life, etc.)"
    )
    certifications: Optional[List[str]] = Field(None, description="Company certifications")
    
    # === CONTENT ===
    description: Optional[str] = Field(None, description="Brand description")
    content: Optional[str] = Field(None, description="Full content (from website, press release, etc.)")
    
    # === TEMPORAL ===
    scraped_date: Optional[str] = Field(None, description="Date scraped")
    last_updated: Optional[str] = Field(None, description="Last update date")
    
    # === METADATA ===
    extra: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")
    
    model_config = ConfigDict(use_enum_values=True)
