"""
Schema for News Articles and Industry Publications
For scraping news sites, press releases, market research
"""

from typing import Optional, List, Dict, Any
from enum import Enum
from pydantic import BaseModel, Field, ConfigDict


class ArticleType(str, Enum):
    """Type of article"""
    NEWS = "news"
    PRESS_RELEASE = "press_release"
    MARKET_RESEARCH = "market_research"
    TRADE_PUBLICATION = "trade_publication"
    BLOG = "blog"
    OTHER = "other"


class NewsArticleSchema(BaseModel):
    """
    Schema for news articles, press releases, market research reports
    """
    
    # === CORE IDENTIFICATION ===
    id: str = Field(..., description="Unique identifier")
    url: str = Field(..., description="Article URL")
    source: str = Field(..., description="Source publication/website")
    article_type: ArticleType = Field(..., description="Article type")
    
    # === CONTENT ===
    title: str = Field(..., description="Article title")
    headline: Optional[str] = Field(None, description="Headline")
    description: Optional[str] = Field(None, description="Article description/summary")
    content: str = Field(..., description="Full article content (plain text)")
    
    # === AUTHORSHIP ===
    author: Optional[str] = Field(None, description="Author name")
    publisher: Optional[str] = Field(None, description="Publisher name")
    
    # === TOPICS & ENTITIES ===
    topics: Optional[List[str]] = Field(None, description="Topics covered")
    brands_mentioned: Optional[List[str]] = Field(None, description="Brands mentioned")
    products_mentioned: Optional[List[str]] = Field(None, description="Products mentioned")
    key_insights: Optional[List[str]] = Field(None, description="Key insights extracted")
    
    # === CONTENT CATEGORIES ===
    categories: Optional[List[str]] = Field(
        None, 
        description="Categories (product launch, market trend, consumer behavior, etc.)"
    )
    tags: Optional[List[str]] = Field(None, description="Tags/keywords")
    
    # === TEMPORAL ===
    published_date: Optional[str] = Field(None, description="Publication date")
    scraped_date: Optional[str] = Field(None, description="Date scraped")
    
    # === MEDIA ===
    image_url: Optional[str] = Field(None, description="Featured image URL")
    
    # === METADATA ===
    extra: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")
    
    model_config = ConfigDict(use_enum_values=True)
