"""
Schema for Regulatory Standards Data
For scraping FDA, Codex, and other regulatory standards documents
"""

from typing import Optional, List, Dict, Any
from enum import Enum
from pydantic import BaseModel, Field, ConfigDict


class RegulatoryBody(str, Enum):
    """Regulatory body types"""
    FDA = "fda"
    CODEX = "codex"
    EU = "eu"
    OTHER = "other"


class RegulatoryStandardsSchema(BaseModel):
    """
    Schema for regulatory standards documents (FDA, Codex, etc.)
    """
    
    # === CORE IDENTIFICATION ===
    id: str = Field(..., description="Unique identifier for the standard")
    url: str = Field(..., description="Source URL of the standard")
    regulatory_body: RegulatoryBody = Field(..., description="Regulatory body (FDA, Codex, etc.)")
    region: str = Field(..., description="Region (US, Global, EU, etc.)")
    
    # === STANDARD INFORMATION ===
    title: str = Field(..., description="Standard title/name")
    legal_category: str = Field(..., description="Legal category (milk chocolate, dark chocolate, etc.)")
    regulation_code: Optional[str] = Field(None, description="Regulation code (e.g., 21 CFR 163)")
    
    # === COMPOSITION REQUIREMENTS ===
    min_chocolate_liquor_percentage: Optional[float] = Field(None, description="Minimum chocolate liquor %")
    min_cocoa_butter_percentage: Optional[float] = Field(None, description="Minimum cocoa butter %")
    min_milk_solids_percentage: Optional[float] = Field(None, description="Minimum milk solids %")
    min_milk_fat_percentage: Optional[float] = Field(None, description="Minimum milk fat %")
    max_sweetener_percentage: Optional[float] = Field(None, description="Maximum sweetener %")
    
    # === INGREDIENT REQUIREMENTS ===
    required_ingredients: Optional[List[str]] = Field(None, description="Required ingredients")
    allowed_ingredients: Optional[List[str]] = Field(None, description="Allowed ingredients")
    prohibited_ingredients: Optional[List[str]] = Field(None, description="Prohibited ingredients")
    
    # === LABELING REQUIREMENTS ===
    label_naming_rules: Optional[str] = Field(None, description="Label naming requirements")
    required_label_statements: Optional[List[str]] = Field(None, description="Required label statements")
    
    # === CONTENT ===
    description: Optional[str] = Field(None, description="Standard description")
    full_text: Optional[str] = Field(None, description="Full regulatory text")
    
    # === TEMPORAL ===
    effective_date: Optional[str] = Field(None, description="Effective date")
    last_updated: Optional[str] = Field(None, description="Last update date")
    scraped_date: Optional[str] = Field(None, description="Date scraped")
    
    # === METADATA ===
    extra: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")
    
    model_config = ConfigDict(use_enum_values=True)
