# Concept Intelligence Schema for Chocolate and Confectionery

Schema designed specifically for **Concept Intelligence Development** focused on chocolate and confectionery products. Based on market intelligence requirements for LLM fine-tuning.

## Overview

This schema captures all data points needed for chocolate/confectionery concept intelligence:
- **Product Taxonomy** - Categories, formats, types, positioning
- **Regulatory Compliance** - FDA and Codex standards (cocoa %, milk solids, etc.)
- **Competitive Intelligence** - Market share, rankings, brand portfolios
- **Consumer Behavior** - Indulgence drivers, health claims, purchase triggers
- **Product Specifications** - Ingredients, certifications, composition

## Schema Structure

### Core Fields
- `id`, `url`, `source` - Product identification
- `title`, `description`, `brand`, `sku` - Basic product info

### Taxonomy (from Excel requirements)
- `subcategory` - Chocolate, Non-Chocolate Candy, or Gum & Mints
- `product_type` - Milk Chocolate Bar, Dark Chocolate Bar, etc.
- `format` - Bar, Boxed, Bite, Filled Bar, etc.
- `chocolate_type` - Milk, Dark, White, Specialty
- `positioning` - Mass/Mainstream, Premium, Artisanal, Better-For-You, etc.
- `inclusion` - Nuts, Caramel, Nougat, Fruit, etc.

### Regulatory Composition (Critical)
- `cocoa_percentage` - Cocoa content %
- `chocolate_liquor_percentage` - Chocolate liquor % (FDA requirement)
- `cocoa_butter_percentage` - Cocoa butter %
- `milk_solids_percentage` - Total milk solids %
- `milk_fat_percentage` - Milk fat %
- `legal_category` - milk chocolate, dark chocolate, white chocolate
- `fda_compliant` - FDA compliance status
- `codex_compliant` - Codex Alimentarius compliance

### Competitive Intelligence
- `market_share` - Market share percentage
- `market_rank` - Market ranking
- `recent_launch_date` - Launch date
- `brand_portfolio` - Other brands in company
- `sustainability_initiatives` - Sustainability programs

### Consumer Behavior
- `indulgence_drivers` - Texture, flavor, nostalgia, etc.
- `health_claims` - Sugar-free, organic, plant-based, etc.
- `flavor_profile` - Flavor characteristics
- `purchase_triggers` - Gifting, comfort, seasonal, etc.

### Product Specifications
- `net_weight` - Product weight
- `ingredients` - List of ingredients
- `certifications` - Fairtrade, Organic, Non-GMO, etc.
- `country_of_origin` - Manufacturing country

### Ratings & Reviews
- `rating` - Average rating (0-5)
- `rating_count` - Number of ratings
- `reviews` - Review texts (no reviewer information)

## Usage

```python
from concept_schema import ConceptIntelligenceSchema, Subcategory, ProductFormat, ChocolateType, Positioning

product = ConceptIntelligenceSchema(
    id="B071X6KY1W",
    url="https://amazon.in/product/B071X6KY1W",
    source="amazon",
    title="Cadbury Dairy Milk Silk Fruit & Nut",
    brand="Cadbury",
    subcategory=Subcategory.CHOCOLATE,
    product_type="Milk Chocolate Bar",
    format=ProductFormat.BAR,
    chocolate_type=ChocolateType.MILK,
    positioning=Positioning.MASS_MAINSTREAM,
    inclusion="Nuts / Fruit",
    chocolate_liquor_percentage=10.0,
    milk_solids_percentage=12.0,
    milk_fat_percentage=3.39,
    legal_category="milk chocolate",
    fda_compliant=True,
    price=175.0,
    currency="INR",
    rating=4.3,
    rating_count=12500
)
```

## Examples

See `concept_examples.py` for complete examples:
- Milk Chocolate Bar (Mass/Mainstream)
- Dark Chocolate Bar (Premium/Health-oriented)
- Premium Truffles (Gift positioning)
- Sugar-Free Chocolate (Better-For-You)
- Hershey's Product (Mass/Mainstream)

Run examples:
```bash
python concept_examples.py
```

## Data Scraping Requirements

See `docs/SCRAPING_REQUIREMENTS_ANALYSIS.md` for detailed scraping requirements:
- E-commerce platforms (Amazon, retailers)
- Regulatory websites (FDA, Codex)
- Brand websites (Hershey, Mars, Cadbury, Lindt, etc.)
- Review platforms
- Industry news

## Key Features

✅ **Regulatory Compliance** - Captures FDA and Codex requirements  
✅ **Taxonomy Alignment** - Matches Excel taxonomy structure  
✅ **Competitive Intelligence** - Market share, rankings, portfolios  
✅ **Consumer Insights** - Behavior patterns and preferences  
✅ **LLM-Ready** - Optimized for fine-tuning  
✅ **Simple Structure** - Easy to read and maintain  

## Requirements

```bash
pip install pydantic
```

## Next Steps

1. Build scrapers for e-commerce platforms
2. Extract regulatory compliance data
3. Collect competitive intelligence
4. Aggregate consumer behavior insights
5. Transform scraped data to this schema
6. Use for LLM fine-tuning
