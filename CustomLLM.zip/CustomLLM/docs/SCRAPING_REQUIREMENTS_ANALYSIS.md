# Data Scraping Requirements Analysis
## Based on: Concept Intelligence Development - Chocolate and Confectionery Learnings

## Executive Summary

The Excel document reveals a comprehensive market intelligence project focused on **chocolate and confectionery products**. The data scraping requirements need to support building a **Concept Intelligence System** that can understand product categories, regulatory standards, competitive landscape, and consumer behavior.

---

## 1. Data Sources Required

### 1.1 E-Commerce Platforms (Primary)
**Purpose:** Extract product information, pricing, reviews, and specifications

**Key Sites:**
- **Amazon** (US, India, Global)
  - Product listings, prices, reviews, ratings
  - Product specifications (cocoa %, ingredients, weight)
  - Brand information
  - Category classifications
  - Seasonal products

- **Walmart, Target, Whole Foods** (US retailers)
  - Product availability
  - Store-specific pricing
  - Private label products

- **Specialty Retailers**
  - Godiva.com (premium chocolate)
  - Lindt.com (premium Swiss chocolate)
  - Local confectionery stores

**Data Points to Scrape:**
- Product title, description, content
- Price (current, original, discount %)
- SKU/Product ID
- Brand name
- Product specifications (cocoa %, milk solids, ingredients)
- Categories (milk chocolate, dark chocolate, white chocolate, etc.)
- Ratings and reviews (text only, no reviewer info)
- Availability status
- Product images
- Format (bar, boxed, bite-size, etc.)
- Positioning (mass, premium, artisanal)

### 1.2 Regulatory & Standards Websites
**Purpose:** Extract legal composition standards and labeling requirements

**Key Sources:**
- **FDA.gov** (US Food and Drug Administration)
  - Chocolate standards (21 CFR 163)
  - Labeling requirements
  - Ingredient regulations
  - Cocoa percentage requirements

- **Codex Alimentarius** (Global standards)
  - International chocolate composition standards
  - Regional variations

**Data Points to Scrape:**
- Legal category names
- Minimum cocoa % requirements
- Milk solids requirements
- Cocoa butter requirements
- Allowed/required ingredients
- Label naming rules
- Regional variations

### 1.3 Brand & Company Websites
**Purpose:** Extract brand portfolios, recent launches, positioning

**Key Brands (from Competitive Intelligence):**
- Hershey (hersheys.com)
- Mars, Inc. (mars.com)
- Mondelēz (cadbury.com, toblerone.com)
- Lindt & Sprüngli (lindt.com)
- Ferrero (ferrero.com)
- Godiva (godiva.com)
- Justin's (justins.com)
- Tony's Chocolonely (tonyschocolonely.com)
- Divine Chocolate (divinechocolate.com)

**Data Points to Scrape:**
- Brand portfolio (key products)
- Recent product launches
- Pricing strategies
- Positioning & marketing claims
- Sustainability certifications
- Market share information
- Product categories per brand

### 1.4 Consumer Review & Social Platforms
**Purpose:** Extract consumer behavior insights, sentiment, preferences

**Key Sources:**
- **Review Sites**
  - Amazon reviews
  - Trustpilot
  - Consumer Reports
  - Specialty food review sites

- **Social Media**
  - Reddit (r/chocolate, r/candy)
  - Instagram (hashtags, brand accounts)
  - TikTok (viral chocolate content)
  - Twitter/X (brand mentions, trends)

**Data Points to Scrape:**
- Review texts (no reviewer info)
- Sentiment (positive/negative/neutral)
- Key themes (indulgence, health, sustainability, flavor)
- Purchase triggers
- Channel preferences
- Format preferences

### 1.5 News & Industry Publications
**Purpose:** Extract market trends, launches, industry news

**Key Sources:**
- Food industry news sites
- Trade publications
- Press releases from brands
- Market research reports

**Data Points to Scrape:**
- Product launch announcements
- Market trends
- Consumer behavior insights
- Pricing changes
- Sustainability initiatives

---

## 2. Specific Data Fields to Scrape

### 2.1 Product Information (E-Commerce)
Based on the schema and Excel requirements:

**Core Fields:**
- `id` - Product identifier (ASIN, SKU, etc.)
- `url` - Product page URL
- `title` - Product name
- `description` - Short description
- `content` - Full product details (plain text)

**E-Commerce Specific:**
- `price` - Current price
- `currency` - Currency code
- `original_price` - Price before discount
- `sku` - Product SKU/identifier
- `brand` - Brand name (Hershey, Cadbury, etc.)
- `availability` - Stock status
- `rating` - Average rating (0-5)
- `rating_count` - Number of ratings
- `reviews` - List of review texts (no reviewer info)

**Product Specifications (Critical for Chocolate):**
- `specifications` - Key-value pairs including:
  - Cocoa % / Chocolate liquor %
  - Milk solids %
  - Milk fat %
  - Cocoa butter %
  - Sugar content
  - Ingredients list
  - Net weight
  - Country of origin
  - Certifications (Fairtrade, Rainforest Alliance, Organic, Non-GMO)

**Categorization:**
- `categories` - Product categories:
  - Subcategory: Chocolate, Non-Chocolate Candy, Gum & Mints
  - Product Type: Milk Chocolate Bar, Dark Chocolate Bar, White Chocolate Bar, etc.
  - Format: Bar, Boxed/Bite, Coated Bar/Treat, Molded, etc.
  - Chocolate Type: Milk, Dark, White
  - Positioning: Mass/Mainstream, Premium, Artisanal, Better-For-You

- `tags` - Keywords:
  - Inclusion types (Nuts, Caramel, Nougat, Fruit, etc.)
  - Flavor profiles
  - Health claims (sugar-free, reduced-sugar, plant-based)
  - Seasonal (Halloween, Easter, Holiday)

**Media:**
- `image_url` - Primary product image
- `image_alt` - Image alt text
- `media_urls` - Additional product images

**Additional:**
- `extra` - Source-specific fields:
  - ASIN (for Amazon)
  - Prime eligible
  - Fulfilled by Amazon
  - Best seller rank
  - Amazon Choice
  - Package dimensions
  - Nutritional information

### 2.2 Regulatory Standards Data
**From FDA and Codex websites:**

- Legal category name
- Minimum cocoa % requirements
- Milk requirements (milk solids %, milk fat %)
- Cocoa butter requirements
- Allowed ingredients
- Required ingredients
- Label naming rules
- Regional variations (US vs Global)

### 2.3 Competitive Intelligence Data
**From brand websites and industry sources:**

- Brand/Company name
- Portfolio (key brands)
- Recent launches (product names, dates, descriptions)
- Pricing strategy
- Pack strategy
- Positioning & claims
- Market share / rank
- Key strengths
- Sustainability initiatives

### 2.4 Consumer Behavior Data
**From reviews, social media, surveys:**

- Indulgence drivers
- Value orientation
- Health consciousness indicators
- Flavor preferences
- Channel preferences (online vs offline)
- Sustainability values
- Purchase triggers
- Format preferences

---

## 3. Schema Mapping

### Current Simple Schema Coverage

✅ **Well Covered:**
- Basic product info (title, description, content)
- Pricing (price, currency, original_price)
- Brand and SKU
- Ratings and reviews (text only)
- Categories and tags
- Images
- Specifications (as key-value dict)

⚠️ **Needs Enhancement:**
- **Chocolate-specific fields** - Need to add to `specifications` or `extra`:
  - Cocoa percentage
  - Chocolate liquor %
  - Milk solids %
  - Milk fat %
  - Cocoa butter %
  - Legal category (milk chocolate, dark chocolate, etc.)
  - Format (bar, boxed, bite-size)
  - Positioning (mass, premium, artisanal)

- **Regulatory compliance** - May need to add:
  - FDA compliance status
  - Codex compliance status
  - Certification badges (Fairtrade, Organic, etc.)

- **Competitive intelligence** - May need to add to `extra`:
  - Market share
  - Competitive positioning
  - Recent launch date
  - Sustainability claims

---

## 4. Scraping Priorities

### Priority 1: Core Product Data (E-Commerce)
**Sites:** Amazon, major retailers
**Frequency:** Daily/Weekly
**Fields:** All product fields + specifications

### Priority 2: Regulatory Standards
**Sites:** FDA.gov, Codex websites
**Frequency:** Monthly (standards change infrequently)
**Fields:** Legal requirements, composition standards

### Priority 3: Brand Intelligence
**Sites:** Brand websites, press releases
**Frequency:** Weekly
**Fields:** Portfolio, launches, positioning

### Priority 4: Consumer Insights
**Sites:** Review sites, social media
**Frequency:** Daily
**Fields:** Reviews, sentiment, trends

---

## 5. Data Quality Requirements

### 5.1 Accuracy
- Cocoa percentages must be exact (regulatory compliance)
- Prices must be current
- Specifications must match product labels

### 5.2 Completeness
- All required fields populated
- Missing data flagged appropriately
- Source attribution maintained

### 5.3 Consistency
- Standardized category names
- Consistent format for specifications
- Unified date formats

### 5.4 Validation
- Cross-reference regulatory standards
- Verify brand information
- Validate pricing against multiple sources

---

## 6. Recommended Schema Enhancements

### Option 1: Extend `specifications` dict
```python
specifications={
    # Standard product specs
    "net_weight": "150g",
    "country_of_origin": "India",
    
    # Chocolate-specific (critical)
    "cocoa_percentage": 50,
    "chocolate_liquor_percentage": 10,
    "milk_solids_percentage": 12,
    "milk_fat_percentage": 3.39,
    "cocoa_butter_percentage": 20,
    "legal_category": "milk_chocolate",
    "format": "bar",
    "positioning": "mass_mainstream",
    "inclusions": ["nuts", "caramel"],
    "certifications": ["fairtrade", "organic"]
}
```

### Option 2: Add chocolate-specific fields to `extra`
```python
extra={
    "chocolate_specs": {
        "cocoa_percentage": 50,
        "legal_category": "milk_chocolate",
        "format": "bar",
        "positioning": "mass_mainstream"
    },
    "regulatory_compliance": {
        "fda_compliant": True,
        "codex_compliant": True
    },
    "competitive_intel": {
        "market_share": 5.3,
        "rank": 4,
        "recent_launch": "2024-01-15"
    }
}
```

**Recommendation:** Use Option 1 (extend `specifications`) for chocolate-specific data that's part of the product itself. Use `extra` for metadata like competitive intelligence.

---

## 7. Implementation Checklist

### Phase 1: E-Commerce Product Scraping
- [ ] Set up Amazon scraper (product pages)
- [ ] Extract core product fields
- [ ] Extract specifications (especially cocoa %)
- [ ] Extract reviews (text only)
- [ ] Handle different product formats (bars, boxed, etc.)
- [ ] Map to categories from taxonomy

### Phase 2: Regulatory Data
- [ ] Scrape FDA chocolate standards
- [ ] Scrape Codex standards
- [ ] Create validation rules
- [ ] Cross-reference product compliance

### Phase 3: Brand Intelligence
- [ ] Scrape brand websites
- [ ] Extract portfolio information
- [ ] Track recent launches
- [ ] Monitor positioning changes

### Phase 4: Consumer Insights
- [ ] Aggregate reviews from multiple sources
- [ ] Extract sentiment
- [ ] Identify trends
- [ ] Track consumer behavior patterns

---

## 8. Key Challenges

1. **Cocoa Percentage Extraction**
   - May be in description, specifications, or images
   - Need OCR for product images
   - Must validate against regulatory standards

2. **Category Classification**
   - Products may fit multiple categories
   - Need to map to taxonomy from Excel
   - Handle regional variations

3. **Regulatory Compliance**
   - Standards vary by region
   - Need to validate products against standards
   - Track changes in regulations

4. **Competitive Intelligence**
   - Data scattered across multiple sources
   - Need to aggregate and normalize
   - Track changes over time

---

## 9. Next Steps

1. **Review and approve** this requirements document
2. **Enhance schema** with chocolate-specific fields
3. **Prioritize data sources** based on business needs
4. **Build scrapers** starting with Priority 1 (E-commerce)
5. **Set up data pipeline** to transform scraped data to schema
6. **Implement validation** against regulatory standards
7. **Create monitoring** for data quality and completeness

---

## 10. Questions to Clarify

1. **Geographic Scope:** US only, or global (India, Europe, etc.)?
2. **Product Scope:** Chocolate only, or all confectionery?
3. **Update Frequency:** How often should data be refreshed?
4. **Data Volume:** Expected number of products to track?
5. **Compliance Focus:** How critical is regulatory compliance validation?
6. **Competitive Intelligence:** Real-time or periodic updates?

---

**Document Version:** 1.0  
**Date:** 2024  
**Based on:** Concept Intelligence Development_Chocolate and Confectionery_Learnings.xlsx
