"""
Examples for Concept Intelligence Schema
Based on actual chocolate/confectionery products from the requirements document
"""

from concept_schema import (
    ConceptIntelligenceSchema,
    Subcategory,
    ProductFormat,
    ChocolateType,
    Positioning
)


def example_milk_chocolate_bar():
    """Example: Milk Chocolate Bar (Mass/Mainstream)"""
    return ConceptIntelligenceSchema(
        id="B071X6KY1W",
        url="https://www.amazon.in/Cadbury-Dairy-Milk-Silk-Fruit/dp/B071X6KY1W",
        source="amazon",
        title="Cadbury Dairy Milk Silk Fruit & Nut Chocolate Bar, 150g",
        description="Premium chocolate bar with roasted almonds and raisins, wrapped in smooth silk chocolate.",
        brand="Cadbury",
        sku="B071X6KY1W",
        subcategory=Subcategory.CHOCOLATE,
        product_type="Milk Chocolate Bar",
        format=ProductFormat.BAR,
        chocolate_type=ChocolateType.MILK,
        positioning=Positioning.MASS_MAINSTREAM,
        inclusion="Nuts / Fruit",
        # Regulatory composition
        chocolate_liquor_percentage=10.0,
        milk_solids_percentage=12.0,
        milk_fat_percentage=3.39,
        legal_category="milk chocolate",
        fda_compliant=True,
        codex_compliant=True,
        # Pricing
        price=175.0,
        currency="INR",
        original_price=200.0,
        # Specifications
        net_weight="150g",
        ingredients=["Sugar", "Cocoa butter", "Milk solids", "Almonds", "Raisins", "Cocoa mass"],
        certifications=["Rainforest Alliance"],
        country_of_origin="India",
        # Ratings
        rating=4.3,
        rating_count=12500,
        reviews=[
            "Amazing chocolate! The combination of fruit and nut is perfect.",
            "Good quality chocolate but a bit expensive.",
            "Best chocolate I've ever had. The almonds add a nice crunch."
        ],
        # Competitive intelligence
        market_rank=4,
        # Brand intelligence
        brand_portfolio=["Dairy Milk", "Bournville", "Toblerone"],
        sustainability_initiatives=["Cocoa Life"],
        marketing_claims=["Premium quality", "Smooth silk texture"],
        # Consumer behavior
        indulgence_drivers=["Texture", "Nostalgia", "Premium experience"],
        flavor_profile=["Fruit", "Nut"],
        purchase_triggers=["Gifting", "Self-indulgence"],
        # Media
        image_url="https://m.media-amazon.com/images/I/81abc123xyz.jpg",
        image_alt="Cadbury Dairy Milk Silk Fruit & Nut Chocolate Bar",
        availability="in_stock",
        channels=["online", "retail"],
        scraped_date="2024-01-29T10:00:00Z"
    )


def example_dark_chocolate_bar():
    """Example: Dark Chocolate Bar (Premium/Health-oriented)"""
    return ConceptIntelligenceSchema(
        id="lindt-excellence-70",
        url="https://www.lindt.com/us/excellence-70-cocoa",
        source="brand_website",
        title="Lindt Excellence 70% Cocoa Dark Chocolate Bar",
        description="Smooth, intense dark chocolate with 70% cocoa content.",
        brand="Lindt",
        subcategory=Subcategory.CHOCOLATE,
        product_type="Dark Chocolate Bar",
        format=ProductFormat.BAR,
        chocolate_type=ChocolateType.DARK,
        positioning=Positioning.PREMIUM,
        # Regulatory composition
        cocoa_percentage=70.0,
        chocolate_liquor_percentage=35.0,
        legal_category="dark chocolate",
        fda_compliant=True,
        codex_compliant=True,
        # Pricing
        price=4.99,
        currency="USD",
        # Specifications
        net_weight="100g",
        ingredients=["Cocoa mass", "Sugar", "Cocoa butter", "Vanilla"],
        certifications=["Rainforest Alliance"],
        country_of_origin="Switzerland",
        # Competitive intelligence
        market_rank=1,
        market_share=5.5,
        # Brand intelligence
        brand_portfolio=["Lindor", "Hello", "Ghirardelli"],
        sustainability_initiatives=["Rainforest Alliance"],
        marketing_claims=["Swiss quality", "Master chocolatier heritage", "Premium indulgence"],
        # Consumer behavior
        health_claims=["Antioxidants", "High cocoa content"],
        flavor_profile=["Intense", "Bittersweet"],
        purchase_triggers=["Health-conscious", "Premium gifting"],
        availability="in_stock",
        channels=["specialty", "online", "retail"],
        scraped_date="2024-01-29T10:00:00Z"
    )


def example_premium_truffles():
    """Example: Premium Truffles (Gift positioning)"""
    return ConceptIntelligenceSchema(
        id="ferrero-rocher-24",
        url="https://www.ferrero.com/products/ferrero-rocher",
        source="brand_website",
        title="Ferrero Rocher Premium Chocolate Collection, 24 pieces",
        description="Italian-style luxury chocolate with whole hazelnut, creamy filling, and crispy wafer.",
        brand="Ferrero",
        subcategory=Subcategory.CHOCOLATE,
        product_type="Truffles & Pralines",
        format=ProductFormat.BOXED,
        chocolate_type=ChocolateType.MILK,
        positioning=Positioning.GIFT,
        inclusion="Nuts / Hazelnut",
        # Regulatory composition
        chocolate_liquor_percentage=10.0,
        milk_solids_percentage=12.0,
        legal_category="milk chocolate",
        fda_compliant=True,
        # Pricing
        price=24.99,
        currency="USD",
        # Specifications
        net_weight="300g",
        ingredients=["Milk chocolate", "Hazelnuts", "Sugar", "Cocoa butter", "Wheat flour"],
        country_of_origin="Italy",
        # Competitive intelligence
        market_rank=1,
        # Brand intelligence
        brand_portfolio=["Kinder", "Tic Tac", "Nutella"],
        marketing_claims=["Italian luxury", "Premium gifting", "Quality ingredients"],
        # Consumer behavior
        indulgence_drivers=["Luxury", "Texture", "Gifting experience"],
        flavor_profile=["Hazelnut", "Creamy"],
        purchase_triggers=["Gifting", "Special occasions", "Luxury treat"],
        availability="in_stock",
        channels=["premium_retail", "online"],
        scraped_date="2024-01-29T10:00:00Z"
    )


def example_sugar_free_chocolate():
    """Example: Sugar-Free Chocolate (Better-For-You positioning)"""
    return ConceptIntelligenceSchema(
        id="justins-dark-chocolate-pieces",
        url="https://www.justins.com/products/dark-chocolate-candy-pieces",
        source="brand_website",
        title="Justin's Dark Chocolate Candy Pieces, Sugar-Free",
        description="Organic dark chocolate pieces with no added sugar, made with organic cocoa.",
        brand="Justin's",
        subcategory=Subcategory.CHOCOLATE,
        product_type="Sugar-Free / Reduced-Sugar Chocolate",
        format=ProductFormat.BITE,
        chocolate_type=ChocolateType.DARK,
        positioning=Positioning.BETTER_FOR_YOU,
        # Regulatory composition
        cocoa_percentage=70.0,
        chocolate_liquor_percentage=35.0,
        legal_category="dark chocolate",
        fda_compliant=True,
        # Pricing
        price=6.49,
        currency="USD",
        # Specifications
        net_weight="4.5oz",
        ingredients=["Organic cocoa", "Organic erythritol", "Organic stevia", "Organic cocoa butter"],
        certifications=["USDA Organic", "Non-GMO", "Rainforest Alliance"],
        # Brand intelligence
        marketing_claims=["Clean indulgence", "USDA Organic", "No artificial sweeteners"],
        # Consumer behavior
        health_claims=["Sugar-free", "Organic", "Non-GMO", "Diabetic-friendly"],
        flavor_profile=["Dark", "Bittersweet"],
        purchase_triggers=["Health goals", "Diabetes management", "Clean eating"],
        availability="in_stock",
        channels=["natural_gourmet", "online"],
        scraped_date="2024-01-29T10:00:00Z"
    )


def example_hershey_product():
    """Example: Hershey's Product (Mass/Mainstream)"""
    return ConceptIntelligenceSchema(
        id="hersheys-milk-chocolate-bar",
        url="https://www.hersheys.com/products/hersheys-milk-chocolate-bar",
        source="brand_website",
        title="Hershey's Milk Chocolate Bar, 1.55oz",
        description="Classic American milk chocolate bar.",
        brand="Hershey",
        subcategory=Subcategory.CHOCOLATE,
        product_type="Milk Chocolate Bar",
        format=ProductFormat.BAR,
        chocolate_type=ChocolateType.MILK,
        positioning=Positioning.MASS_MAINSTREAM,
        # Regulatory composition
        chocolate_liquor_percentage=10.0,
        milk_solids_percentage=12.0,
        milk_fat_percentage=3.39,
        legal_category="milk chocolate",
        fda_compliant=True,
        # Pricing
        price=1.29,
        currency="USD",
        # Specifications
        net_weight="1.55oz",
        ingredients=["Sugar", "Milk", "Chocolate", "Cocoa butter", "Lecithin", "Vanilla"],
        country_of_origin="USA",
        # Competitive intelligence
        market_rank=4,
        market_share=5.3,
        # Brand intelligence
        brand_portfolio=["Reese's", "Kisses", "Kit Kat", "Twizzlers"],
        sustainability_initiatives=["Cocoa For Good"],
        marketing_claims=["Classic American", "Nostalgia", "Sharing"],
        # Consumer behavior
        indulgence_drivers=["Nostalgia", "Classic flavor"],
        purchase_triggers=["Everyday treat", "Sharing", "Nostalgia"],
        availability="in_stock",
        channels=["mass_retail", "online", "convenience"],
        scraped_date="2024-01-29T10:00:00Z"
    )


if __name__ == "__main__":
    examples = [
        ("Milk Chocolate Bar (Mass)", example_milk_chocolate_bar),
        ("Dark Chocolate Bar (Premium)", example_dark_chocolate_bar),
        ("Premium Truffles (Gift)", example_premium_truffles),
        ("Sugar-Free Chocolate (Better-For-You)", example_sugar_free_chocolate),
        ("Hershey's Product (Mass)", example_hershey_product)
    ]
    
    for name, example_func in examples:
        print(f"\n{'='*80}")
        print(f"Example: {name}")
        print(f"{'='*80}")
        data = example_func()
        print(f"ID: {data.id}")
        print(f"Brand: {data.brand}")
        print(f"Product Type: {data.product_type}")
        print(f"Format: {data.format}")
        print(f"Chocolate Type: {data.chocolate_type}")
        print(f"Positioning: {data.positioning}")
        print(f"Legal Category: {data.legal_category}")
        if data.cocoa_percentage:
            print(f"Cocoa %: {data.cocoa_percentage}%")
        if data.chocolate_liquor_percentage:
            print(f"Chocolate Liquor %: {data.chocolate_liquor_percentage}%")
        if data.milk_solids_percentage:
            print(f"Milk Solids %: {data.milk_solids_percentage}%")
        print(f"FDA Compliant: {data.fda_compliant}")
        print(f"Price: {data.currency} {data.price}")
        
        # Convert to dict
        data_dict = data.model_dump(exclude_none=True)
        print(f"\nFields populated: {len([v for v in data_dict.values() if v is not None])}")
        print(f"Schema validation: ✓ Valid")
