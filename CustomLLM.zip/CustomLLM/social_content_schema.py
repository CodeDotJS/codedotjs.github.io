"""
Schema for Social Media and Consumer Content
For scraping Reddit, Instagram, TikTok, Twitter, review sites
"""

from typing import Optional, List, Dict, Any
from enum import Enum
from pydantic import BaseModel, Field, ConfigDict


class ContentType(str, Enum):
    """Type of social content"""
    POST = "post"
    COMMENT = "comment"
    REVIEW = "review"
    DISCUSSION = "discussion"
    TREND = "trend"


class Platform(str, Enum):
    """Social media platforms"""
    REDDIT = "reddit"
    INSTAGRAM = "instagram"
    TIKTOK = "tiktok"
    TWITTER = "twitter"
    TRUSTPILOT = "trustpilot"
    AMAZON_REVIEWS = "amazon_reviews"
    OTHER = "other"


class Sentiment(str, Enum):
    """Sentiment classification"""
    POSITIVE = "positive"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"
    MIXED = "mixed"


class SocialContentSchema(BaseModel):
    """
    Schema for social media posts, comments, reviews, discussions
    """
    
    # === CORE IDENTIFICATION ===
    id: str = Field(..., description="Unique identifier")
    url: Optional[str] = Field(None, description="Content URL")
    platform: Platform = Field(..., description="Platform (Reddit, Instagram, etc.)")
    content_type: ContentType = Field(..., description="Content type (post, comment, review, etc.)")
    
    # === CONTENT ===
    title: Optional[str] = Field(None, description="Post/title (for Reddit, etc.)")
    content: str = Field(..., description="Main content text")
    hashtags: Optional[List[str]] = Field(None, description="Hashtags")
    mentions: Optional[List[str]] = Field(None, description="Brand/product mentions")
    
    # === CONTEXT ===
    topic: Optional[str] = Field(None, description="Topic/subreddit/channel")
    related_brands: Optional[List[str]] = Field(None, description="Related brands mentioned")
    related_products: Optional[List[str]] = Field(None, description="Related products mentioned")
    
    # === SENTIMENT & THEMES ===
    sentiment: Optional[Sentiment] = Field(None, description="Sentiment (positive, negative, neutral)")
    themes: Optional[List[str]] = Field(
        None, 
        description="Key themes (indulgence, health, sustainability, flavor, etc.)"
    )
    purchase_triggers: Optional[List[str]] = Field(None, description="Purchase triggers mentioned")
    flavor_preferences: Optional[List[str]] = Field(None, description="Flavor preferences mentioned")
    
    # === ENGAGEMENT ===
    views: Optional[int] = Field(None, description="View count")
    likes: Optional[int] = Field(None, description="Like count")
    shares: Optional[int] = Field(None, description="Share count")
    comments_count: Optional[int] = Field(None, description="Comment count")
    upvotes: Optional[int] = Field(None, description="Upvotes (Reddit)")
    
    # === TEMPORAL ===
    published_date: Optional[str] = Field(None, description="Publication date")
    scraped_date: Optional[str] = Field(None, description="Date scraped")
    
    # === METADATA ===
    extra: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")
    
    model_config = ConfigDict(use_enum_values=True)
