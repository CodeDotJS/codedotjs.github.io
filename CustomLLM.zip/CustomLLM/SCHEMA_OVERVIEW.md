# Schema Overview - Concept Intelligence Development

## Summary

You're absolutely correct! The original schema (`concept_schema.py`) is **product-focused** and designed for e-commerce product data. However, the requirements document mentions **5 different data source types**, each needing different schemas.

## Schema Breakdown by Data Source

### 1. ✅ Product Data Schema (`concept_schema.py`)
**For:** E-commerce platforms (Amazon, Walmart, brand product pages)
- Product information
- Pricing, ratings, reviews
- Product specifications
- Regulatory compliance status
- Competitive intelligence (product-level)

**Sources:**
- Amazon, Walmart, Target, Whole Foods
- Brand product pages

---

### 2. ✅ Regulatory Standards Schema (`regulatory_schema.py`)
**For:** FDA, Codex, regulatory standards documents
- Legal requirements
- Composition standards
- Labeling rules
- Ingredient regulations

**Sources:**
- FDA.gov (21 CFR 163)
- Codex Alimentarius
- EU regulations

---

### 3. ✅ Brand Intelligence Schema (`brand_intelligence_schema.py`)
**For:** Brand/company-level data
- Brand portfolios
- Company information
- Market share/rankings
- Recent launches
- Sustainability initiatives

**Sources:**
- Brand websites (hersheys.com, cadbury.com, etc.)
- Press releases
- Company reports

---

### 4. ✅ Social Content Schema (`social_content_schema.py`)
**For:** Social media, reviews, discussions
- Posts, comments, reviews
- Sentiment analysis
- Consumer behavior insights
- Trends and discussions

**Sources:**
- Reddit (r/chocolate, r/candy)
- Instagram, TikTok, Twitter
- Review sites (Trustpilot, etc.)

---

### 5. ✅ News Article Schema (`news_article_schema.py`)
**For:** News, press releases, market research
- News articles
- Press releases
- Market research reports
- Trade publications

**Sources:**
- Food industry news sites
- Press releases
- Market research reports

---

## Which Schema to Use?

| Data Source | Schema to Use |
|------------|---------------|
| Amazon product page | `concept_schema.py` |
| Walmart product page | `concept_schema.py` |
| Brand product page | `concept_schema.py` |
| FDA.gov standards | `regulatory_schema.py` |
| Codex standards | `regulatory_schema.py` |
| Brand website (company info) | `brand_intelligence_schema.py` |
| Press release | `news_article_schema.py` or `brand_intelligence_schema.py` |
| Reddit post | `social_content_schema.py` |
| Instagram post | `social_content_schema.py` |
| News article | `news_article_schema.py` |
| Market research report | `news_article_schema.py` |

---

## Implementation Strategy

### Option 1: Use All Schemas (Recommended)
- Use appropriate schema for each data source
- Transform scraped data to matching schema
- Store in separate collections/tables
- Combine for LLM training

### Option 2: Unified Schema
- Create one mega-schema with all fields
- Use optional fields based on content type
- More complex but single schema

**Recommendation:** Use Option 1 - separate schemas are cleaner and more maintainable.

---

## Next Steps

1. ✅ Product schema - Already created (`concept_schema.py`)
2. ✅ Regulatory schema - Created (`regulatory_schema.py`)
3. ✅ Brand intelligence schema - Created (`brand_intelligence_schema.py`)
4. ✅ Social content schema - Created (`social_content_schema.py`)
5. ✅ News article schema - Created (`news_article_schema.py`)

All schemas are now ready for their respective data sources!
