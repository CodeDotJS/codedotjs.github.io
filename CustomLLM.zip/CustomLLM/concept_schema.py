"""
Concept Intelligence Schema for Chocolate and Confectionery Products
Based on: Concept Intelligence Development - Chocolate and Confectionery Learnings

This schema is designed specifically for scraping and storing data about
chocolate and confectionery products for LLM fine-tuning.
"""

from typing import Optional, List, Dict, Any, Union
from enum import Enum
from pydantic import BaseModel, Field, ConfigDict


class ChocolateType(str, Enum):
    """Chocolate type classification"""
    MILK = "milk"
    DARK = "dark"
    WHITE = "white"
    SPECIALTY = "specialty"


class ProductFormat(str, Enum):
    """Product format/package type"""
    BAR = "bar"
    BOXED = "boxed"
    BITE = "bite"
    FILLED_BAR = "filled_bar"
    COATED_TREAT = "coated_treat"
    MOLDED = "molded"
    SPECIALTY = "specialty"


class Positioning(str, Enum):
    """Market positioning"""
    MASS_MAINSTREAM = "mass_mainstream"
    PREMIUM = "premium"
    ARTISANAL = "artisanal"
    BETTER_FOR_YOU = "better_for_you"
    HEALTH_ORIENTED = "health_oriented"
    GIFT = "gift"
    SEASONAL = "seasonal"
    SNACK = "snack"
    BOUTIQUE = "boutique"


class Subcategory(str, Enum):
    """Confectionery subcategory"""
    CHOCOLATE = "chocolate"
    NON_CHOCOLATE_CANDY = "non_chocolate_candy"
    GUM_MINTS = "gum_mints"


class ConceptIntelligenceSchema(BaseModel):
    """
    Schema for Chocolate and Confectionery Concept Intelligence data.
    Designed for LLM fine-tuning based on market intelligence requirements.
    """
    
    # === CORE IDENTIFICATION ===
    id: str = Field(..., description="Unique product identifier (ASIN, SKU, etc.)")
    url: str = Field(..., description="Product page URL")
    source: str = Field(..., description="Source platform (amazon, walmart, brand_website, etc.)")
    
    # === PRODUCT INFORMATION ===
    title: str = Field(..., description="Product name/title")
    description: Optional[str] = Field(None, description="Product description")
    brand: str = Field(..., description="Brand name (Hershey, Cadbury, Lindt, etc.)")
    sku: Optional[str] = Field(None, description="Product SKU/identifier")
    
    # === TAXONOMY (from Excel structure) ===
    subcategory: Subcategory = Field(..., description="Subcategory: Chocolate, Non-Chocolate Candy, or Gum & Mints")
    product_type: str = Field(..., description="Product type (e.g., Milk Chocolate Bar, Dark Chocolate Bar)")
    format: ProductFormat = Field(..., description="Product format (bar, boxed, bite, etc.)")
    chocolate_type: Optional[ChocolateType] = Field(None, description="Chocolate type (milk, dark, white, specialty)")
    positioning: Positioning = Field(..., description="Market positioning")
    inclusion: Optional[str] = Field(None, description="Inclusions (Nuts, Caramel, Nougat, Fruit, etc.)")
    
    # === REGULATORY COMPOSITION (Critical for Chocolate) ===
    cocoa_percentage: Optional[float] = Field(None, ge=0, le=100, description="Cocoa percentage")
    chocolate_liquor_percentage: Optional[float] = Field(None, ge=0, le=100, description="Chocolate liquor % (FDA requirement)")
    cocoa_butter_percentage: Optional[float] = Field(None, ge=0, le=100, description="Cocoa butter %")
    milk_solids_percentage: Optional[float] = Field(None, ge=0, le=100, description="Total milk solids %")
    milk_fat_percentage: Optional[float] = Field(None, ge=0, le=100, description="Milk fat %")
    legal_category: Optional[str] = Field(None, description="Legal category (milk chocolate, dark chocolate, white chocolate per FDA)")
    fda_compliant: Optional[bool] = Field(None, description="FDA compliance status")
    codex_compliant: Optional[bool] = Field(None, description="Codex Alimentarius compliance status")
    
    # === PRICING ===
    price: Optional[float] = Field(None, description="Current price")
    currency: Optional[str] = Field(None, description="Currency code (USD, INR, etc.)")
    original_price: Optional[float] = Field(None, description="Original price before discount")
    
    # === PRODUCT SPECIFICATIONS ===
    net_weight: Optional[str] = Field(None, description="Net weight (e.g., '150g', '5oz')")
    ingredients: Optional[List[str]] = Field(None, description="List of ingredients")
    certifications: Optional[List[str]] = Field(None, description="Certifications (Fairtrade, Organic, Non-GMO, Rainforest Alliance, etc.)")
    country_of_origin: Optional[str] = Field(None, description="Country of origin")
    shelf_life: Optional[str] = Field(None, description="Shelf life information")
    
    # === RATINGS & REVIEWS ===
    rating: Optional[float] = Field(None, ge=0, le=5, description="Average rating (0-5)")
    rating_count: Optional[int] = Field(None, ge=0, description="Number of ratings")
    reviews: Optional[List[str]] = Field(None, description="Review texts (no reviewer information)")
    
    # === COMPETITIVE INTELLIGENCE ===
    market_share: Optional[float] = Field(None, description="Market share percentage")
    market_rank: Optional[int] = Field(None, description="Market rank")
    recent_launch_date: Optional[str] = Field(None, description="Recent launch date (if applicable)")
    launch_description: Optional[str] = Field(None, description="Description of recent launch")
    
    # === BRAND INTELLIGENCE ===
    brand_portfolio: Optional[List[str]] = Field(None, description="Other brands in company portfolio")
    sustainability_initiatives: Optional[List[str]] = Field(None, description="Sustainability programs (Cocoa For Good, Cocoa Life, etc.)")
    marketing_claims: Optional[List[str]] = Field(None, description="Marketing claims and positioning statements")
    
    # === CONSUMER BEHAVIOR INSIGHTS ===
    indulgence_drivers: Optional[List[str]] = Field(None, description="Indulgence drivers (texture, flavor, nostalgia, etc.)")
    health_claims: Optional[List[str]] = Field(None, description="Health claims (sugar-free, reduced-sugar, plant-based, etc.)")
    flavor_profile: Optional[List[str]] = Field(None, description="Flavor profile (tropical, swicy, global flavors, etc.)")
    purchase_triggers: Optional[List[str]] = Field(None, description="Purchase triggers (comfort, gifting, seasonal, etc.)")
    
    # === MEDIA ===
    image_url: Optional[str] = Field(None, description="Primary product image URL")
    image_alt: Optional[str] = Field(None, description="Image alt text")
    
    # === AVAILABILITY ===
    availability: Optional[str] = Field(None, description="Availability status")
    channels: Optional[List[str]] = Field(None, description="Sales channels (online, retail, specialty, etc.)")
    
    # === TEMPORAL ===
    scraped_date: Optional[str] = Field(None, description="Date when data was scraped (ISO format)")
    
    # === ADDITIONAL METADATA ===
    extra: Optional[Dict[str, Any]] = Field(None, description="Additional source-specific data")
    
    model_config = ConfigDict(
        use_enum_values=True,
        json_schema_extra={
            "example": {
                "id": "B071X6KY1W",
                "url": "https://amazon.in/product/B071X6KY1W",
                "source": "amazon",
                "title": "Cadbury Dairy Milk Silk Fruit & Nut Chocolate Bar, 150g",
                "brand": "Cadbury",
                "subcategory": "chocolate",
                "product_type": "Milk Chocolate Bar",
                "format": "bar",
                "chocolate_type": "milk",
                "positioning": "mass_mainstream",
                "inclusion": "Nuts / Fruit",
                "cocoa_percentage": 50.0,
                "chocolate_liquor_percentage": 10.0,
                "milk_solids_percentage": 12.0,
                "milk_fat_percentage": 3.39,
                "legal_category": "milk chocolate",
                "fda_compliant": True,
                "price": 175.0,
                "currency": "INR",
                "net_weight": "150g",
                "rating": 4.3,
                "rating_count": 12500
            }
        }
    )